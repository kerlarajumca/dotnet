﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace client
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] bytes = new byte[1024];   
            IPAddress hostip = IPAddress.Parse("127.0.0.1");
            int port = 3030;
            IPEndPoint endpoint = new IPEndPoint(hostip, port);
            try
            {
                Socket sender = new Socket(hostip.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                sender.Connect(endpoint);

                byte[] msg = Encoding.ASCII.GetBytes("Hello Server....<EOF>");
                int bytesSent = sender.Send(msg);
                int bytesRec = sender.Receive(bytes);
                Console.WriteLine("Echoed test = {0}",
                Encoding.ASCII.GetString(bytes, 0, bytesRec));
                sender.Shutdown(SocketShutdown.Both);
                sender.Close(); 

               
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
    
    }
}
